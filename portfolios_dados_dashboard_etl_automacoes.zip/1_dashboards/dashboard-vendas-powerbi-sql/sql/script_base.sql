CREATE TABLE Vendas (
    ID INT PRIMARY KEY,
    DataVenda DATE,
    Produto VARCHAR(100),
    Categoria VARCHAR(50),
    Quantidade INT,
    Preco DECIMAL(10, 2),
    Canal VARCHAR(50)
);

-- Exemplo de consulta
SELECT 
    Categoria,
    SUM(Quantidade * Preco) AS ReceitaTotal,
    COUNT(ID) AS TotalVendas
FROM Vendas
GROUP BY Categoria;
