# Dashboard de Vendas com Power BI e SQL Server
Este projeto exibe dados de vendas conectando Power BI ao SQL Server.