# Análise de Marketing Digital com Looker Studio
Dashboard conectado ao Google Analytics mostrando sessões, rejeição e conversões.