# Automação de Dados Financeiros com Airflow
Pipeline de ETL simples usando Airflow para extrair e carregar dados financeiros.