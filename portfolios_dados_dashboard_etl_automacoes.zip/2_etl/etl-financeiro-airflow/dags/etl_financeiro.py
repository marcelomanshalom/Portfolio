from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
import pandas as pd

def extrair():
    df = pd.read_csv('/path/financas.csv')
    df.to_csv('/tmp/financas_tratadas.csv', index=False)

def carregar():
    pass

with DAG('etl_financeiro', start_date=datetime(2023,1,1), schedule_interval='@weekly', catchup=False) as dag:
    extrair_dados = PythonOperator(task_id='extrair', python_callable=extrair)
    carregar_dados = PythonOperator(task_id='carregar', python_callable=carregar)
    extrair_dados >> carregar_dados
