# Data Warehouse para Vendas com SSIS
Criação de modelo dimensional para análise de vendas.