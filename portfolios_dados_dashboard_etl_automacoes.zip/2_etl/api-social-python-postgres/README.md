# Integração de Dados de Mídia Social
Script para consumir API e salvar dados no PostgreSQL.