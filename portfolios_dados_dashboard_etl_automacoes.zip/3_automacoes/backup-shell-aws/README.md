# Automação de Backup com Shell Script
Script para compactar e enviar backup para AWS S3.