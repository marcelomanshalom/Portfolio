# Boas-Vindas Automáticas com N8N
Fluxo para enviar e-mail a novos clientes via API.