# Automação de Relatórios Semanais
Geração de relatórios com Python e envio via Power Automate.