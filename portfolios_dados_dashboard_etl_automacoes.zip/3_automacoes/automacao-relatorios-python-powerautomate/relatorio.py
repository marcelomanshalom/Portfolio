import pandas as pd
df = pd.read_csv('dados.csv')
df.to_excel('relatorio_semanal.xlsx', index=False)
